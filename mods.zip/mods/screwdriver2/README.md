Improved node rotation tool.

![bbcode>markdown](http://kland.smilebasicsource.com/i/kwdeu.png)

https://forum.minetest.net/viewtopic.php?f=9&t=20856
