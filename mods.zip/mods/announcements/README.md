# Announcements
Mod to announce random messages to players

# Configuration

You can add messages by adding this to your minetest.conf file:
```txt
announce_messages = Message1, Message2, Message3
```

You can change the interval of messages (in seconds) with this setting
```txt
announce_interval = 600
```

# Toggle Announcements

You can toggle announcements with the `/announcements_toggle` command.