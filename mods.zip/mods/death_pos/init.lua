local death_pos = {}
local tip_sent = {}

minetest.register_on_dieplayer(function(player, reason)
    local name = player:get_player_name()
    local send_tip = minetest.settings:get_bool("death_pos.send_tip_on_die", true)
    death_pos[name] = player:get_pos()
    if send_tip and not tip_sent[name] then
        minetest.chat_send_player(name, minetest.colorize("#60e645", "You died. You can return back to your last death position by using the bone finder, tap it and stand still for 5 seconds to be teleported."))
        tip_sent[name] = true
        minetest.after(10, function()
            tip_sent[name] = nil
        end)
    end
end)

minetest.register_node("death_pos:bone_finder", {
    description = "Bone Finder",
    tiles = {
        "gbones_top.png^[transform2",
        "gbones_bottom.png",
        "gbones_side.png",
        "gbones_side.png",
        "gbones_rear.png",
        "gbones_front.png"
    },
    groups = {cracky = 3, level = 2},
    sounds = default.node_sound_stone_defaults(),

    on_rightclick = function(pos, node, player, itemstack, pointed_thing)
        local name = player:get_player_name()
        local death_position = death_pos[name]

        if not death_position then
            minetest.chat_send_player(name, "You don't have a death position right now.")
            return
        end

        minetest.sound_play("bonefinder", {to_player = name, gain = 1.0})

        minetest.chat_send_player(name, "Stand still for 5 seconds to be teleported to your bones.")
        
        local initial_pos = player:get_pos()
        minetest.after(5, function()
            if vector.distance(player:get_pos(), initial_pos) > 0.1 then
                minetest.chat_send_player(name, "You moved! Teleportation canceled.")
            else
                player:set_pos(death_position)
                minetest.chat_send_player(name, minetest.colorize("#60e645", "Teleported you back to your death position!"))
                -- Remove the following line to allow multiple teleports
                -- death_pos[name] = nil 
            end
        end)
    end,
})

minetest.register_craft({
    output = "death_pos:bone_finder",
    recipe = {
        {"", "", ""},
        {"bones:bones", "default:mese", ""},
        {"", "", ""},
    }
})